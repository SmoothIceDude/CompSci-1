
public class HolidayBonus {

	public static double[] calculateHolidayBonus(double[][] data, double high, double low, 
			double other) {
		
		double answer[];
		answer = new double[data.length];
		
		double subsequent = -1; 
		int subsequentIndex = -1;
		double momentary = -1;
		int momentaryIndex = -1;
		
		for(int i = 0; i < data.length; i++) {
			double total = 0;
			
			for(int z = 0; z < data[i].length; z++) {
				total = total + data[i][z];
			}
			
			if(total < subsequent || subsequent == -1) {
				subsequent = total;
				subsequentIndex = i;
			}
			
			if(momentary < total || momentary == -1) {
				momentary = total;
				momentaryIndex = i;
			}
		}
		
		for(int i = 0; i < data.length; i++) {
			if(i == subsequentIndex) {
				answer[i] = low;
				continue;
			}
			
			if(i == momentaryIndex) {
				answer[i] = high;
			}
			
			answer[i] = other;
		}
				return answer;
	}
	
	public static double calculateTotalHolidayBonus(double[][] data, double high, double low, 
			double other) {
		double[] totalHolidayBonus = calculateHolidayBonus(data, high, low, other);
		double totalBonus = 0;
		
		for(double holidayBonus: totalHolidayBonus) {
			totalBonus = totalBonus + holidayBonus;
		}
				return totalBonus;
	}
}
