import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class TwoDimRaggedArrayUtility {

	public static double[][] readFile(File file) throws FileNotFoundException {
		Scanner keyboard = new Scanner(file);
	
		int counter = 0;
		String [][] subsequentFile = new String[10][];
		
		while (keyboard.hasNextLine() == true) {
			String[] raggedRow = keyboard.nextLine().split("");
			subsequentFile[counter] = new String[raggedRow.length];
			
			for(int i = 0; i < raggedRow.length; i++) {
				subsequentFile[counter][i] = raggedRow[i];
			}
			counter = counter + 1;
		}
		
		double[][] informationFile = new double[counter][];
		for(int i = 0; i < counter; i++) {
			informationFile[i] = new double[subsequentFile[i].length];
			for(int z = 0; z < subsequentFile[i].length; z++) {
				System.out.print(subsequentFile[i][z] + " ");
				informationFile[i][z] = Double.parseDouble(subsequentFile[i][z]);
			}
			System.out.println();
		}
		
		keyboard.close();
		return informationFile;
	}
	
	public static void writeToFile(double [][] data, File outputFile) throws FileNotFoundException {
		PrintWriter fileWriter = new PrintWriter(outputFile);
		StringBuilder separateString = new StringBuilder();
		
		for(int i = 0; i < data.length; i++) {
			for(int z = 0; z < data[i].length; z++) {
				separateString.append(data[i][z] + " ");
			}
			separateString.append("\n");
		}
		fileWriter.print(separateString.toString());
		fileWriter.close();
	}
	
	public static double getTotal(double[][] data) {
		double sum = 0;
		
		for(int i = 0; i < data.length; i++) {
			for(int z = 0; z < data[i].length; z++) {
				sum = sum + data[i][z];
			}
		}
		return sum;
	}
	
	public static double getAverage(double[][] data) {
		int index = 0;
		double sum = 0, average = 0;
		
		for(int i = 0; i < data.length; i++) {
			for(int z = 0; z < data[i].length; z++) {
				sum = sum + data[i][z];
				index++;
			}
		}
		average = (sum / index);
		
		return average;
	}
	
	public static double getRowTotal(double[][] data, int row) {
		double rowTotal = 0;
		
		for(int i = 0; i < data[row].length; i++) {
			rowTotal = rowTotal + data[row][i];
		}
		
		return rowTotal;
	}
	
	public static double getColumnTotal(double[][] data, int col) {
		double columnTotal = 0;
		
		for(int i = 0; i < data.length; i++) {
			if(col >= data[i].length) {
				continue;
			}
			columnTotal = columnTotal + data[i][col];
		}
		return columnTotal;
	}
	
	public static double getHighestInRow(double[][] data, int row) {
		double highestInRow = Double.MIN_VALUE;
		
		for(int i = 0; i < data[row].length; i++) {
			if(data[row][i] > highestInRow) {
				highestInRow = data[row][i];
			}
		}
		return highestInRow;
	}
	
	public static int getHighestInRowIndex(double[][] data, int row) {
		double highestInRowIndex = Double.MIN_VALUE;
		int precision = -1;
		
		for(int i = 0; i < data[row].length; i++) {
			if(data[row][i] > highestInRowIndex) {
				highestInRowIndex = data[row][i];
				precision = i;
			}
		}
		return precision;
	}
	
	public static double getLowestInRow(double[][] data, int row) {
		double lowestInRow = Double.MAX_VALUE;
		
		for(int i = 0; i < data[row].length; i++) {
			if(data[row][i] < lowestInRow) {
				lowestInRow = data[row][i];
			}
		}
		return lowestInRow;
	}
	
	public static int getLowestInRowIndex(double[][] data, int row) {
		double lowestInRowIndex = Double.MAX_VALUE;
		
		int precision = -1;
		
		for(int i = 0; i < data[row].length; i++) {
			if(data[row][i] < lowestInRowIndex) {
				lowestInRowIndex = data[row][i];
				precision = i;
			}
		}
		return precision;
	}
	
	public static double getHighestInColumn(double[][] data, int col) {
		double highestInColumn = Double.MIN_VALUE;
		
		for(int i = 0; i < data.length; i++) {
			if(col >= data[i].length) {
				continue;
			}
			
			if(data[i][col] > highestInColumn) {
				highestInColumn = data[i][col];
			}
		}
		return highestInColumn;
	}
	
	public static int getHighestInColumnIndex(double[][] data, int col) {
		double highestInColumnIndex = Double.MIN_VALUE;
		int precision = -1;
		
		for(int i = 0; i < data.length; i++) {
			if(col >= data[i].length) {
				continue;
			}
			
			if(data[i][col] > highestInColumnIndex) {
				highestInColumnIndex = data[i][col];
				precision = i;
			}
		}
		return precision;
	}
	
	public static double getLowestInColumn(double[][] data, int col) {
		double lowestInColumn = Double.MAX_VALUE;
		
		for(int i = 0; i < data.length; i++) {
			if(col >= data[i][col]) {
				continue;
			}
			
			if(data[i][col] < lowestInColumn) {
				lowestInColumn = data[i][col];
			}
		}
		return lowestInColumn;
	}
	
	public static int getLowestInColumnIndex(double[][] data, int col) {
		double lowestInColumnIndex = Double.MAX_VALUE;
		int precision = -1;
		
		for(int i = 0; i < data.length; i++) {
			if(col >= data[i][col]) {
				continue;
			}
			
			if(data[i][col] < lowestInColumnIndex) {
				lowestInColumnIndex = data[i][col];
				precision = i;
			}
		}
		return precision;
	}
	
	public static double getHighestInArray(double[][] data) {
		double highestInArray = Double.MIN_VALUE;
		
		for(int i = 0; i < data.length; i++) {
			for(int z = 0; z < data[i].length; z++) {
				if(data[i][z] > highestInArray) {
					highestInArray = data[i][z];
				}
			}
		}
		return highestInArray;
	}
	
	public static double getLowestInArray(double[][] data) {
		double lowestInArray = Double.MAX_VALUE;
		
		for(int i = 0; i < data.length; i++) {
			for(int z = 0; z < data[i].length; z++) {
				if(data[i][z] < lowestInArray) {
					lowestInArray = data[i][z];
				}
			}
		}
		return lowestInArray;
	}
}
