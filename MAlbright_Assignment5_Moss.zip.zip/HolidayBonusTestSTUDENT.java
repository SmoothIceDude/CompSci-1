import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class HolidayBonusTestSTUDENT {
	
	private double[][] dataSetSTUDENTONE = {{5,4,3},{8,9},{7,8}};

	@Before
	public void setUp() throws Exception {
	}
	
	@After
	public void tearDown() throws Exception {
		dataSetSTUDENTONE = null;
	}

	@Test
	public void testCalculateHolidayBonusSTUDENTA() {
		try {
			double[] solution = HolidayBonus.calculateHolidayBonus(dataSetSTUDENTONE, 5000, 1000, 2000);
			assertEquals(1000.0, solution[0], .001);
		} catch (Exception e) {
			fail("Exception should occur at this point!");
		} 
	}
	
	@Test
	public void testCalculateHolidayBonusSTUDENTB() {
		try {
			double[] solution = HolidayBonus.calculateHolidayBonus(dataSetSTUDENTONE,1000, 250, 500);
			assertEquals(500.0, solution[1], .001);
		} catch (Exception e) {
			fail("Exception should occur at this point!");
		} 	
	}

	@Test
	public void testCalculateTotalHolidayBonusA() {
		assertEquals(5000.0, HolidayBonus.calculateTotalHolidayBonus(dataSetSTUDENTONE, 5000, 1000, 2000), .001);
	}
	
	@Test
	public void testCalculateTotalHolidayBonusB() {
		assertEquals(1250.0, HolidayBonus.calculateTotalHolidayBonus(dataSetSTUDENTONE, 1000, 250, 500), .001);
	}

}